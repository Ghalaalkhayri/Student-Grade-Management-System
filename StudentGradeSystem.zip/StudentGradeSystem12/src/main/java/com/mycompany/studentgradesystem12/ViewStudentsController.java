/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.studentgradesystem12;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;

public class ViewStudentsController {

    @FXML
    private TableView<StudentGradeRow> studentsTable;

    @FXML
    private TableColumn<StudentGradeRow, String> idColumn;

    @FXML
    private TableColumn<StudentGradeRow, String> nameColumn;

    @FXML
    private TableColumn<StudentGradeRow, String> majorColumn;

    @FXML
    private TableColumn<StudentGradeRow, String> courseColumn;

    @FXML
    private TableColumn<StudentGradeRow, String> gradeColumn;

    @FXML
    private Label resultLabel;

    private ObservableList<StudentGradeRow> tableData = FXCollections.observableArrayList();

    @FXML
    private void initialize() {
        idColumn.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getStudentId()));
        nameColumn.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getStudentName()));
        majorColumn.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getMajor()));
        courseColumn.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getCourse()));
        gradeColumn.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getGrade()));

        studentsTable.setItems(tableData);

        loadStudentsAndGrades();
    }

    @FXML
    private void loadStudentsAndGrades() {
        tableData.clear();

        File studentsFile = new File("students.txt");
        File gradesFile = new File("grades.txt");

        boolean foundStudents = false;

        if (studentsFile.exists()) {
            try {
                BufferedReader studentReader = new BufferedReader(new FileReader(studentsFile));
                String studentLine;

                while ((studentLine = studentReader.readLine()) != null) {
                    String[] studentData = studentLine.split(",");

                    if (studentData.length >= 3) {
                        String studentId = studentData[0].trim();
                        String studentName = studentData[1].trim();
                        String major = studentData[2].trim();

                        foundStudents = true;
                        boolean foundGrade = false;

                        if (gradesFile.exists()) {
                            BufferedReader gradeReader = new BufferedReader(new FileReader(gradesFile));
                            String gradeLine;

                            while ((gradeLine = gradeReader.readLine()) != null) {
                                String[] gradeData = gradeLine.split(",");

                                if (gradeData.length >= 3) {
                                    String gradeStudentId = gradeData[0].trim();
                                    String course = gradeData[1].trim();
                                    String gradeValue = gradeData[2].trim();

                                    if (studentId.equals(gradeStudentId)) {
                                        tableData.add(new StudentGradeRow(
                                                studentId,
                                                studentName,
                                                major,
                                                course,
                                                gradeValue
                                        ));

                                        foundGrade = true;
                                    }
                                }
                            }

                            gradeReader.close();
                        }

                        if (!foundGrade) {
                            tableData.add(new StudentGradeRow(
                                    studentId,
                                    studentName,
                                    major,
                                    "No course",
                                    "No grade"
                            ));
                        }
                    }
                }

                studentReader.close();

            } catch (IOException e) {
                resultLabel.setText("Error reading files!");
                return;
            }
        }

        if (!foundStudents) {
            loadStudentsFromMemory();
        }

        if (tableData.isEmpty()) {
            resultLabel.setText("No students found.");
        } else {
            resultLabel.setText("Students loaded successfully.");
        }
    }

    private void loadStudentsFromMemory() {
        File gradesFile = new File("grades.txt");

        for (Student student : App.allStudents) {
            boolean foundGrade = false;

            if (gradesFile.exists()) {
                try {
                    BufferedReader gradeReader = new BufferedReader(new FileReader(gradesFile));
                    String gradeLine;

                    while ((gradeLine = gradeReader.readLine()) != null) {
                        String[] gradeData = gradeLine.split(",");

                        if (gradeData.length >= 3) {
                            int gradeStudentId = Integer.parseInt(gradeData[0].trim());
                            String course = gradeData[1].trim();
                            String gradeValue = gradeData[2].trim();

                            if (student.getID() == gradeStudentId) {
                                tableData.add(new StudentGradeRow(
                                        String.valueOf(student.getID()),
                                        student.getName(),
                                        student.getMajor(),
                                        course,
                                        gradeValue
                                ));

                                foundGrade = true;
                            }
                        }
                    }

                    gradeReader.close();

                } catch (IOException | NumberFormatException e) {
                    resultLabel.setText("Error reading grades file!");
                    return;
                }
            }

            if (!foundGrade) {
                tableData.add(new StudentGradeRow(
                        String.valueOf(student.getID()),
                        student.getName(),
                        student.getMajor(),
                        "No course",
                        "No grade"
                ));
            }
        }
    }

    @FXML
    private void goToDashboard() throws IOException {
        App.setRoot("Dashboard");
    }

    public static class StudentGradeRow {

        private String studentId;
        private String studentName;
        private String major;
        private String course;
        private String grade;

        public StudentGradeRow(String studentId, String studentName, String major, String course, String grade) {
            this.studentId = studentId;
            this.studentName = studentName;
            this.major = major;
            this.course = course;
            this.grade = grade;
        }

        public String getStudentId() {
            return studentId;
        }

        public String getStudentName() {
            return studentName;
        }

        public String getMajor() {
            return major;
        }

        public String getCourse() {
            return course;
        }

        public String getGrade() {
            return grade;
        }
    }
}