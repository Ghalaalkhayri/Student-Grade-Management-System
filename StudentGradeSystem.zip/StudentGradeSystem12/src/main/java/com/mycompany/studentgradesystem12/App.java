package com.mycompany.studentgradesystem12;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.ArrayList;

/**
 * JavaFX App
 */
public class App extends Application {

    private static Scene scene;
 final static String username = "admin";
    final static String password = "1234";
        public static ArrayList<Student> allStudents = new ArrayList<Student>();
    @Override
    public void start(Stage stage) throws IOException {
        scene = new Scene(loadFXML("Login"), 800, 500);
        stage.setScene(scene);
        stage.setTitle("Student Grade System️");
        stage.show();
    }

    static void setRoot(String fxml) throws IOException {
        scene.setRoot(loadFXML(fxml));
    }

    private static Parent loadFXML(String fxml) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(App.class.getResource(fxml + ".fxml"));
        return fxmlLoader.load();
    }

    public static void main(String[] args) {
        launch();
    }

}