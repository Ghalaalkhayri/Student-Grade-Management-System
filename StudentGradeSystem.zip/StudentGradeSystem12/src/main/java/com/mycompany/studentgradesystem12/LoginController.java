package com.mycompany.studentgradesystem12;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;

public class LoginController implements Initializable {

    @FXML
    TextField uesrNameText;
    @FXML
    PasswordField  PasswordTextt;
     @FXML
    Label resultlbl;
     /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    @FXML
private void goToPassword() {
    PasswordTextt.requestFocus();
}
    @FXML
    private void switchToDashboardController() throws IOException {
        
       if(uesrNameText.getText().equals(App.username)&&PasswordTextt.getText().equals(App.password))
        App.setRoot("Dashboard");
        else{resultlbl.setText("Invalid Username or Password");}
    }
}
