package com.mycompany.studentgradesystem12;

import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;

public class AddStudentController implements Initializable {

    @FXML
    private TextField nameField;
    @FXML
    private TextField idField;
    @FXML
    private TextField majorField;
    @FXML
    private Label resultLabel;
    @FXML
    private Button addButton;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // nothing needed here
    }

    @FXML
    private void goToID() {
        idField.requestFocus();
    }

    @FXML
    private void goToMajor() {
        majorField.requestFocus();
    }

    @FXML
    private void goToAddButton() {
        addButton.requestFocus();
    }

    @FXML
    private void addStudent() throws IOException {
        String name   = nameField.getText().trim();
        String idText = idField.getText().trim();
        String major  = majorField.getText().trim();

        // check empty fields
        if (name.isEmpty() || idText.isEmpty() || major.isEmpty()) {
            resultLabel.setStyle("-fx-text-fill: #e74c3c;");
            resultLabel.setText("⚠ Please fill all fields.");
            return;
        }

        // check ID is numbers only
        int id;
        try {
            id = Integer.parseInt(idText);
        } catch (NumberFormatException e) {
            resultLabel.setStyle("-fx-text-fill: #e74c3c;");
            resultLabel.setText("⚠ Student ID must contain numbers only.");
            return;
        }

        // check duplicate ID
        for (Student s : App.allStudents) {
            if (s.getID() == id) {
                resultLabel.setStyle("-fx-text-fill: #e74c3c;");
                resultLabel.setText("⚠ Student ID already exists.");
                return;
            }
        }

        // add student
        Student newStudent = new Student(name, id, major);
        App.allStudents.add(newStudent);

        // save to students.txt
        FileWriter fw = new FileWriter("students.txt", true);
        fw.write(name + "," + id + "," + major + ",0.0\n");
        fw.close();

        resultLabel.setStyle("-fx-text-fill: #27ae60;");
        resultLabel.setText("✔ Student added successfully!");

        // clear fields after adding
        nameField.clear();
        idField.clear();
        majorField.clear();
        nameField.requestFocus();
    }

    @FXML
    private void clearFields() {
        nameField.clear();
        idField.clear();
        majorField.clear();
        resultLabel.setText("");
        nameField.requestFocus();
    }

    @FXML
    private void goToDashboard() throws IOException {
        App.setRoot("Dashboard");
    }
}
