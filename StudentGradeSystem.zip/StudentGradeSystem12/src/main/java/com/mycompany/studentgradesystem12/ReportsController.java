/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.studentgradesystem12;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import java.util.Locale;

public class ReportsController {

    @FXML
    private Label totalStudentsLabel;

    @FXML
    private Label averageGradeLabel;

    @FXML
    private Label highestGradeLabel;

    @FXML
    private Label resultLabel;

    @FXML
    private void initialize() {
        generateReport();
    }

    @FXML
    private void generateReport() {
        int totalStudents = countStudents();
        double totalGrades = 0;
        double highestGrade = 0;
        int gradeCount = 0;

        File gradesFile = new File("grades.txt");

        if (gradesFile.exists()) {
            try {
                BufferedReader reader = new BufferedReader(new FileReader(gradesFile));
                String line;

                while ((line = reader.readLine()) != null) {
                    String[] data = line.split(",");

                    if (data.length >= 3) {
                        try {
                            double grade = Double.parseDouble(data[2].trim());

                            totalGrades += grade;
                            gradeCount++;

                            if (grade > highestGrade) {
                                highestGrade = grade;
                            }

                        } catch (NumberFormatException e) {
                            // Ignore wrong grade values
                        }
                    }
                }

                reader.close();

            } catch (IOException e) {
                resultLabel.setText("Error reading grades file!");
                return;
            }
        }

        totalStudentsLabel.setText("Number of Students: " + totalStudents);

        if (gradeCount > 0) {
            double average = totalGrades / gradeCount;

            averageGradeLabel.setText("Average Grade: " + String.format(Locale.US, "%.2f", average));
            highestGradeLabel.setText("Highest Grade: " + String.format(Locale.US, "%.2f", highestGrade));
            resultLabel.setText("Report generated successfully.");
        } else {
            averageGradeLabel.setText("Average Grade: No grades found");
            highestGradeLabel.setText("Highest Grade: No grades found");
//            resultLabel.setText("No grades available.");
        }
    }

    private int countStudents() {
        int count = 0;
        File studentsFile = new File("students.txt");

        if (studentsFile.exists()) {
            try {
                BufferedReader reader = new BufferedReader(new FileReader(studentsFile));
                String line;

                while ((line = reader.readLine()) != null) {
                    if (!line.trim().isEmpty()) {
                        count++;
                    }
                }

                reader.close();

            } catch (IOException e) {
                return 0;
            }
        } else {
            count = App.allStudents.size();
        }

        return count;
    }

    @FXML
    private void goToDashboard() throws IOException {
        App.setRoot("Dashboard");
    }
}