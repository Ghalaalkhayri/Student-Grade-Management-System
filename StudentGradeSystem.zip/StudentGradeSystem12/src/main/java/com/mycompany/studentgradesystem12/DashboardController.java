package com.mycompany.studentgradesystem12;

import java.io.IOException;
import javafx.fxml.FXML;

public class DashboardController {

    @FXML
    private void goToAddStudent() throws IOException {
        App.setRoot("AddStudent");
    }
      @FXML
    private void goToAddGrades() throws IOException {
        App.setRoot("AddGrades");
    }
        @FXML
    private void goToViewStudents() throws IOException {
        App.setRoot("ViewStudents");
    }
          @FXML
    private void goToReports() throws IOException {
        App.setRoot("Reports");
    }
           @FXML
    private void switchToLogin() throws IOException {
        App.setRoot("Login");
    }
}
