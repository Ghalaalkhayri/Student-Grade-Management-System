/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.studentgradesystem12;

import java.io.FileWriter;
import java.io.PrintWriter;
import java.io.IOException;
import javafx.fxml.FXML;
import javafx.scene.control.*;
/**
 *
 * @author Marwa
 */
public class AddGradesController {
    
    @FXML
    TextField idField;
    @FXML
    TextField courseField;
    @FXML
    TextField gradeField;
    @FXML
    Label resultLabel;

    @FXML
    private void addGrade() {
        String idText = idField.getText();
        String course = courseField.getText();
        String gradeText = gradeField.getText();

   
        if (idText.isEmpty() || course.isEmpty() || gradeText.isEmpty()) {
            resultLabel.setText("Please fill all fields!");
            return;
        }

        try {
    
            int studentId = Integer.parseInt(idText);
            double gradeValue = Double.parseDouble(gradeText);

  
            Grade newGrade = new Grade(studentId, course, gradeValue);

         
            FileWriter fw = new FileWriter("grades.txt", true);
            PrintWriter pw = new PrintWriter(fw);
            
      
            pw.println(newGrade.getStudentID() + "," + newGrade.getCourse() + "," + newGrade.getGradeValue());
            pw.close();

            
            resultLabel.setText("Grade saved successfully!");
            idField.clear();
            courseField.clear();
            gradeField.clear();

        } catch (NumberFormatException e) {
    
            resultLabel.setText("Error: ID and Grade must be numbers!");
        } catch (IOException e) {
   
            resultLabel.setText("Error saving to file!");
        }
    }

  
    @FXML
    private void goToDashboard() throws IOException {
        App.setRoot("Dashboard");
    }
}
