module com.mycompany.studentgradesystem12 {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.base;

    opens com.mycompany.studentgradesystem12 to javafx.fxml;
    exports com.mycompany.studentgradesystem12;
}
